# Digital_Crime_Bureau_app
A multi user android application for the problem statement given by the National Crime Records Bureau in SIH 2020.Tech stack used in this project is Android and Firebase as DataStorage.

Video Preview link:-
https://drive.google.com/file/d/1jrQdkyM5lw5EMLs3MFsSVnI9oh5Zom0q/preview

Screen Shots

![Splash_screen](https://user-images.githubusercontent.com/46351652/97830349-a45aa780-1cf2-11eb-8c52-b779a67c04e0.png)
 ![main_page](https://user-images.githubusercontent.com/46351652/94019405-61421600-fdcf-11ea-8972-1c05713d68c1.png)
 ![user](https://user-images.githubusercontent.com/46351652/94019763-c4cc4380-fdcf-11ea-9a63-d46cd39a0065.jpg)
 ![NOC_form](https://user-images.githubusercontent.com/46351652/97830397-d10ebf00-1cf2-11eb-893d-781d926a8b91.png)


