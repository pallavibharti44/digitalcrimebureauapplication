package com.example.student2;

public class Noc_applicationDB {



    String fullname,present_address,home_address,father,mother,life_partner,dob,age,dob_place,education,arressted,politics,present_work,date,station;

    public Noc_applicationDB(){

    }

    public Noc_applicationDB(String fullname, String present_address, String home_address, String father, String mother, String life_partner, String dob, String age, String dob_place, String education, String arressted, String politics, String present_work, String date, String station) {
        this.fullname = fullname;
        this.present_address = present_address;
        this.home_address = home_address;
        this.father = father;
        this.mother = mother;
        this.life_partner = life_partner;
        this.dob = dob;
        this.age = age;
        this.dob_place = dob_place;
        this.education = education;
        this.arressted = arressted;
        this.politics = politics;
        this.present_work = present_work;
        this.date = date;
        this.station = station;
    }

    public String getFullname() {
        return fullname;
    }

    public String getPresent_address() {
        return present_address;
    }

    public String getHome_address() {
        return home_address;
    }

    public String getFather() {
        return father;
    }

    public String getMother() {
        return mother;
    }

    public String getLife_partner() {
        return life_partner;
    }

    public String getDob() {
        return dob;
    }

    public String getAge() {
        return age;
    }

    public String getDob_place() {
        return dob_place;
    }

    public String getEducation() {
        return education;
    }

    public String getArressted() {
        return arressted;
    }

    public String getPolitics() {
        return politics;
    }

    public String getPresent_work() {
        return present_work;
    }

    public String getDate() {
        return date;
    }

    public String getStation() {
        return station;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public void setPresent_address(String present_address) {
        this.present_address = present_address;
    }

    public void setHome_address(String home_address) {
        this.home_address = home_address;
    }

    public void setFather(String father) {
        this.father = father;
    }

    public void setMother(String mother) {
        this.mother = mother;
    }

    public void setLife_partner(String life_partner) {
        this.life_partner = life_partner;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setDob_place(String dob_place) {
        this.dob_place = dob_place;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public void setArressted(String arressted) {
        this.arressted = arressted;
    }

    public void setPolitics(String politics) {
        this.politics = politics;
    }

    public void setPresent_work(String present_work) {
        this.present_work = present_work;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setStation(String station) {
        this.station = station;
    }
}
